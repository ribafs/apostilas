PSR-8 Meta Document
===================

1. Summary
----------

The intent of this spec is to improve the overall amicability and cooperative
spirit of the PHP community through a standardized means of inter-project
affection and support.

2. Votes
--------

- **Entrance Vote:**
- **Acceptance Vote:**

3. Errata
---------

4. People
---------

### 5.1 Editor

- Larry Garfield

### 5.2 Sponsors

- Vacant (Coordinator)
- Vacant
