function Company() {
  return (
    <div>
      <h1>Empresa</h1>
    </div>
  )
}

export default Company