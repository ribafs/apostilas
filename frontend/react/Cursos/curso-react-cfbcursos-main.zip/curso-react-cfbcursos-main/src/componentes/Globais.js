export default class Globais{
    static canal = "CFB Cursos"
    static curso = "Curso de React"
    static ano = 2021
    static resumo = "Curso de React do canal CFB Cursos"
}