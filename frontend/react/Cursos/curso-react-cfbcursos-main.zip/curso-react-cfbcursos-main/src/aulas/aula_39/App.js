import React from 'react';
import './App.css';
import ListaCarros from './componentes/ListaCarros';

export default function App() {

  return (
    <>
      <ListaCarros />
    </>
  );
}