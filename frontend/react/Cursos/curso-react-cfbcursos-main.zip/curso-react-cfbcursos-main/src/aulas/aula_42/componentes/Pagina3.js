import React from 'react';

export default function Pagina3() {

  return (
    <div>
      <h1>Página 3</h1>
      <h3>React Router</h3>
    </div>
  );
}