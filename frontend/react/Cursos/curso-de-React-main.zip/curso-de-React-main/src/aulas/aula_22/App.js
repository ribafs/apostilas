import React from 'react';
import './App.css';
import Carro from './componentes/Carro';

export default function App() {

  return (
    <>
      <h1>Componentes de classe</h1>
      <Carro />
    </>
  );
}