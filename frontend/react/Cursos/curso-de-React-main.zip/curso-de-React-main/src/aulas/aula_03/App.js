import React from 'react';

export default function App() {
  return (
    <section>
      <p>CFB Cursos</p>
      <br />
      <p>Curso de React</p>
    </section>
  );
}
