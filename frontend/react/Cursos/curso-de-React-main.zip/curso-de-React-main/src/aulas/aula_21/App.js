import React from 'react';
import './App.css';
import Classe from './componentes/Classe';

export default function App() {


  return (
    <>
      <h1>Componentes de classe</h1>
      <Classe canal="CFB Cursos" curso="React" />
    </>
  );
}