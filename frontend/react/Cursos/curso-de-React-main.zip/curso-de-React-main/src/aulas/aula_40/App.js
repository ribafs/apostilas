import React from 'react';
import './App.css';
import ListaCarros2 from './componentes/ListaCarros2';

export default function App() {

  return (
    <>
      <ListaCarros2 />
    </>
  );
}