import React from 'react';

export default function App() {
  const canal = "CFB Cursos";
  const curso = "Curso de React";
  return (
    <section>
      <p>Canal: {canal}</p>
      <p>{curso}</p>
    </section>
  );
}
