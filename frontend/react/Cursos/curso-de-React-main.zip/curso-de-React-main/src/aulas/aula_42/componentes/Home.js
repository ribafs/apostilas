import React from 'react';

export default function Home() {

  return (
    <div>
      <h1>Home</h1>
      <h3>Página Principal</h3>
    </div>
  );
}