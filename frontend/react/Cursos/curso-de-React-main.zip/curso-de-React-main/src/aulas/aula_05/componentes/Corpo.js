import React from 'react'

export default function Corpo() {
  return (
    <section>
      <h2>Curso de React</h2>
      <p>Se inscreva em nosso Canal</p>
      <p>Ative o sininho e clique no joinha</p>
    </section>
  )
}
