import React from 'react';

export default function Pagina1() {

  return (
    <div>
      <h1>Página 1</h1>
      <h3>Curso de React</h3>
    </div>
  );
}