import React from 'react'

function Canal(){
  return(
    <>
      <h1>CFB Cursos</h1>
    </>
  )
}

export default Canal